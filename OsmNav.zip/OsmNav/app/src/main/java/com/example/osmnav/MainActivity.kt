package com.example.osmnav

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlinx.coroutines.delay
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import org.osmdroid.tileprovider.tilesource.XYTileSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.net.URL
import java.util.PriorityQueue
import kotlin.math.*
import java.net.URLEncoder

const val MAPTILER_KEY = "__MAPTILER_KEY__" // подставляется при сборке из секрета GitHub

fun tileSource() =
    if (MAPTILER_KEY.isBlank() || MAPTILER_KEY.startsWith("__"))
        XYTileSource("Carto", 0, 19, 256, ".png",
            arrayOf("https://a.basemaps.cartocdn.com/rastertiles/voyager/", "https://b.basemaps.cartocdn.com/rastertiles/voyager/",
                "https://c.basemaps.cartocdn.com/rastertiles/voyager/"), "© OpenStreetMap, © CARTO")
    else
        XYTileSource("MapTiler", 0, 20, 256, ".png?key=$MAPTILER_KEY",
            arrayOf("https://api.maptiler.com/maps/streets-v2/256/"), "© MapTiler © OpenStreetMap")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = "OsmNavApp/1.0 (Android)"
        enableEdgeToEdge()
        setContent { NavTheme { App() } }
    }
}

/** MD3 Expressive + Monet (dynamic color на Android 12+) */
@Composable
fun NavTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    // Expressive-стиль: крупные скругления + динамические цвета Monet
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(12.dp), small = RoundedCornerShape(16.dp),
            medium = RoundedCornerShape(28.dp), large = RoundedCornerShape(36.dp),
            extraLarge = RoundedCornerShape(48.dp)
        ),
        content = content
    )
}

data class Place(val name: String, val lat: Double, val lon: Double)
data class Step(val text: String, val point: GeoPoint, val arrive: Boolean)
data class Route(val points: List<GeoPoint>, val meters: Double, val seconds: Double, val steps: List<Step>)

fun ruText(type: String, mod: String?, name: String, exit: Int): String {
    val on = if (name.isNotBlank()) " на $name" else ""
    val turn = when (mod) {
        "left" -> "поверните налево"; "right" -> "поверните направо"
        "slight left" -> "примите левее"; "slight right" -> "примите правее"
        "sharp left" -> "поверните резко налево"; "sharp right" -> "поверните резко направо"
        "uturn" -> "развернитесь"; else -> "продолжайте прямо"
    }
    return when (type) {
        "arrive" -> "вы прибыли в пункт назначения"
        "roundabout", "rotary", "roundabout turn" -> "на круговом движении езжайте по $exit-му съезду$on"
        "fork" -> "держитесь ${if (mod?.contains("left") == true) "левее" else "правее"}$on"
        "continue", "new name" -> "продолжайте прямо$on"
        else -> turn + (if (mod == "uturn") "" else on)
    }
}

private fun http(url: String): String =
    (URL(url).openConnection() as java.net.HttpURLConnection).run {
        setRequestProperty("User-Agent", "OsmNav/1.0 (android)")
        inputStream.bufferedReader().readText()
    }

suspend fun search(q: String): List<Place> = withContext(Dispatchers.IO) {
    val arr = JSONArray(http("https://nominatim.openstreetmap.org/search?format=json&limit=6&q=" + URLEncoder.encode(q, "UTF-8")))
    (0 until arr.length()).map { arr.getJSONObject(it) }
        .map { Place(it.getString("display_name"), it.getString("lat").toDouble(), it.getString("lon").toDouble()) }
}

suspend fun reverse(p: GeoPoint): String = withContext(Dispatchers.IO) {
    JSONObject(http("https://nominatim.openstreetmap.org/reverse?format=json&accept-language=ru&lat=${p.latitude}&lon=${p.longitude}")).getString("display_name")
}

// ===== Собственный маршрутизатор: граф дорог строится и считается на телефоне (A*) =====
@Volatile var lastError = ""

class Edge(val to: Int, val m: Double, val sec: Double, val name: String)

fun distM(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
    val dLat = Math.toRadians(bLat - aLat); val dLon = Math.toRadians(bLon - aLon)
    val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(aLat)) * cos(Math.toRadians(bLat)) * sin(dLon / 2).pow(2)
    return 2 * 6371000.0 * asin(sqrt(h))
}

fun bearing(a: GeoPoint, b: GeoPoint): Double {
    val la1 = Math.toRadians(a.latitude); val la2 = Math.toRadians(b.latitude)
    val dl = Math.toRadians(b.longitude - a.longitude)
    val y = sin(dl) * cos(la2)
    val x = cos(la1) * sin(la2) - sin(la1) * cos(la2) * cos(dl)
    return (Math.toDegrees(atan2(y, x)) + 360) % 360
}

// Только ДАННЫЕ дорог OSM (Overpass). Сам маршрут считает приложение.
fun overpass(q: String): String? {
    for (host in listOf("https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter")) {
        try {
            val c = URL(host + "?data=" + URLEncoder.encode(q, "UTF-8")).openConnection() as java.net.HttpURLConnection
            c.setRequestProperty("User-Agent", "OsmNavApp/1.0 (Android)")
            c.connectTimeout = 20000; c.readTimeout = 120000
            if (c.responseCode == 200) return c.inputStream.bufferedReader().readText()
            lastError = "сервер дорог ответил кодом ${c.responseCode}"
        } catch (e: Exception) { lastError = "нет связи с сервером дорог (${e.javaClass.simpleName})" }
    }
    return null
}

suspend fun route(a: GeoPoint, b: GeoPoint): Route? = try {
    lastError = ""
    routeImpl(a, b)
} catch (e: Throwable) {
    lastError = "${e.javaClass.simpleName}: ${e.message}"
    null
}

suspend fun routeImpl(a: GeoPoint, b: GeoPoint): Route? = withContext(Dispatchers.IO) {
    val span = max(abs(a.latitude - b.latitude), abs(a.longitude - b.longitude))
    if (span > 1.5) { lastError = "слишком далеко"; return@withContext null }
    val pad = max(0.008, span * 0.25)
    val bs = min(a.latitude, b.latitude) - pad; val bn = max(a.latitude, b.latitude) + pad
    val bw = min(a.longitude, b.longitude) - pad; val be = max(a.longitude, b.longitude) + pad
    val major = "motorway|trunk|primary|secondary|motorway_link|trunk_link|primary_link|secondary_link"
    val types = when {
        span > 0.3 -> major
        span > 0.08 -> "$major|tertiary|tertiary_link|unclassified"
        else -> "$major|tertiary|tertiary_link|unclassified|residential|living_street"
    }
    val q = "[out:json][timeout:90];way[\"highway\"~\"^($types)\$\"]($bs,$bw,$bn,$be);out geom;"
    val txt = overpass(q) ?: return@withContext null
    val els = JSONObject(txt).getJSONArray("elements")

    val idx = HashMap<Long, Int>(); val lat = ArrayList<Double>(); val lon = ArrayList<Double>()
    val adj = ArrayList<ArrayList<Edge>>()
    fun node(id: Long, la: Double, lo: Double): Int = idx.getOrPut(id) { lat.add(la); lon.add(lo); adj.add(ArrayList()); lat.size - 1 }

    for (i in 0 until els.length()) {
        val wy = els.getJSONObject(i)
        val tags = wy.optJSONObject("tags") ?: continue
        val ns = wy.optJSONArray("nodes") ?: continue
        val g = wy.optJSONArray("geometry") ?: continue
        if (ns.length() != g.length()) continue
        val hw = tags.optString("highway")
        val name = tags.optString("name", tags.optString("ref", ""))
        val kmh = tags.optString("maxspeed", "").takeWhile { it.isDigit() }.toIntOrNull() ?: when (hw) {
            "motorway" -> 90; "trunk" -> 80; "primary" -> 60; "secondary" -> 50; "tertiary" -> 45
            "unclassified" -> 40; "residential" -> 30; "living_street" -> 10; else -> 40
        }
        val ow = tags.optString("oneway")
        val round = tags.optString("junction") == "roundabout"
        val fwd = ow != "-1"
        val bwd = ow == "-1" || !(ow == "yes" || ow == "1" || ow == "true" || round || hw.startsWith("motorway"))
        for (k in 0 until ns.length() - 1) {
            val g1 = g.optJSONObject(k) ?: continue
            val g2 = g.optJSONObject(k + 1) ?: continue
            val u = node(ns.getLong(k), g1.getDouble("lat"), g1.getDouble("lon"))
            val v = node(ns.getLong(k + 1), g2.getDouble("lat"), g2.getDouble("lon"))
            val m = distM(lat[u], lon[u], lat[v], lon[v]); val sec = m / (kmh / 3.6)
            if (fwd) adj[u].add(Edge(v, m, sec, name))
            if (bwd) adj[v].add(Edge(u, m, sec, name))
        }
    }
    if (lat.isEmpty()) { lastError = "в этой области нет данных о дорогах"; return@withContext null }

    fun nearest(p: GeoPoint): Int {
        var best = -1; var bd = Double.MAX_VALUE
        for (i in lat.indices) { val d = distM(p.latitude, p.longitude, lat[i], lon[i]); if (d < bd) { bd = d; best = i } }
        return best
    }
    val src = nearest(a); val dst = nearest(b)
    val n = lat.size
    val dist = DoubleArray(n) { Double.MAX_VALUE }
    val prev = IntArray(n) { -1 }
    val prevE = arrayOfNulls<Edge>(n)
    val closed = BooleanArray(n)
    val vmax = 130 / 3.6
    val pq = PriorityQueue<DoubleArray>(11, Comparator<DoubleArray> { x, y -> x[0].compareTo(y[0]) })
    dist[src] = 0.0; pq.add(doubleArrayOf(0.0, src.toDouble()))
    while (pq.isNotEmpty()) {
        val u = pq.poll()!![1].toInt()
        if (closed[u]) continue
        closed[u] = true
        if (u == dst) break
        for (ed in adj[u]) {
            val nd = dist[u] + ed.sec
            if (nd < dist[ed.to]) {
                dist[ed.to] = nd; prev[ed.to] = u; prevE[ed.to] = ed
                pq.add(doubleArrayOf(nd + distM(lat[ed.to], lon[ed.to], lat[dst], lon[dst]) / vmax, ed.to.toDouble()))
            }
        }
    }
    if (src != dst && prev[dst] < 0) { lastError = "путь не найден (дороги не связаны, узлов: $n)"; return@withContext null }

    val path = ArrayList<Int>()
    var c = dst
    while (c != -1) { path.add(c); c = prev[c] }
    path.reverse()
    val pts = path.map { GeoPoint(lat[it], lon[it]) }
    var meters = 0.0; var secs = 0.0
    for (i in 1 until path.size) { val ed = prevE[path[i]]!!; meters += ed.m; secs += ed.sec }

    val steps = ArrayList<Step>()
    for (i in 1 until path.size - 1) {
        val inE = prevE[path[i]]!!; val outE = prevE[path[i + 1]]!!
        val d = ((bearing(pts[i], pts[i + 1]) - bearing(pts[i - 1], pts[i]) + 540) % 360) - 180
        val branches = adj[path[i]].count { it.to != path[i - 1] }
        val nameChange = outE.name.isNotBlank() && outE.name != inE.name
        if (branches >= 2 && (abs(d) > 30 || (nameChange && abs(d) > 15))) {
            val mod = when {
                d > 120 -> "sharp right"; d > 60 -> "right"; d > 0 -> "slight right"
                d < -120 -> "sharp left"; d < -60 -> "left"; else -> "slight left"
            }
            steps.add(Step(ruText("turn", mod, outE.name, 1), pts[i], false))
        }
    }
    steps.add(Step(ruText("arrive", null, "", 1), pts.last(), true))
    Route(listOf(a) + pts + listOf(b), meters, secs, steps)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Place>()) }
    var dest by remember { mutableStateOf<Place?>(null) }
    var info by remember { mutableStateOf<Route?>(null) }
    var loading by remember { mutableStateOf(false) }
    var locOverlay by remember { mutableStateOf<MyLocationNewOverlay?>(null) }
    var navigating by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<Place?>(null) }
    var startPlace by remember { mutableStateOf<Place?>(null) }
    var hint by remember { mutableStateOf("") }
    val tts = remember {
        val h = arrayOfNulls<TextToSpeech>(1)
        h[0] = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) h[0]?.language = Locale("ru", "RU") }
        h[0]!!
    }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    fun say(t: String) { hint = t; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nav") }

    val map = remember {
        MapView(ctx).apply {
            setTileSource(tileSource())
            setMultiTouchControls(true)
            keepScreenOn = true
            controller.setZoom(14.0)
            controller.setCenter(GeoPoint(55.7558, 37.6173))
        }
    }
    fun enableLocation() {
        if (locOverlay != null) return
        val o = MyLocationNewOverlay(GpsMyLocationProvider(ctx), map).apply { enableMyLocation(); enableFollowLocation() }
        map.overlays.add(o); locOverlay = o
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.any { g -> g }) enableLocation()
    }
    LaunchedEffect(Unit) {
        permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) map.onResume()
            if (e == Lifecycle.Event.ON_PAUSE) map.onPause()
        }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob); map.onDetach() }
    }

    LaunchedEffect(navigating, info) {
        val r = info
        if (!navigating || r == null) return@LaunchedEffect
        var i = 0; var far = false; var near = false
        say("Начинаем движение")
        while (i < r.steps.size) {
            delay(1000)
            val me = locOverlay?.myLocation ?: continue
            val s = r.steps[i]
            val d = me.distanceToAsDouble(s.point)
            map.controller.animateTo(me)
            if (!far && d < 400 && d > 80) { far = true; say("Через ${(d / 50).toInt() * 50} метров, ${s.text}") }
            if (!near && d <= 80) { near = true; far = true; say(s.text) }
            if (d < 25) {
                if (s.arrive) { navigating = false; break }
                i++; far = false; near = false
            }
        }
        navigating = false
    }

    fun go(p: Place) {
        dest = p; results = emptyList(); loading = true
        scope.launch {
            picked = null
            val sp = startPlace
            val from = if (sp != null) GeoPoint(sp.lat, sp.lon) else (locOverlay?.myLocation ?: (map.mapCenter as GeoPoint))
            val to = GeoPoint(p.lat, p.lon)
            val r = runCatching { route(from, to) }.getOrNull()
            map.overlays.removeAll { it is Polyline || it is Marker }
            map.overlays.add(Marker(map).apply { position = to; title = p.name })
            if (sp != null) map.overlays.add(Marker(map).apply { position = from; title = "Старт"; id = "start" })
            if (r != null) {
                map.overlays.add(Polyline(map).apply { setPoints(r.points); outlinePaint.strokeWidth = 14f })
                map.zoomToBoundingBox(org.osmdroid.util.BoundingBox.fromGeoPoints(r.points), true, 150)
            } else map.controller.animateTo(to)
            info = r; loading = false; map.invalidate()
        }
    }

    fun clearPick() { map.overlays.removeAll { it is Marker && it.id == "pick" }; map.invalidate() }
    fun pick(g: GeoPoint) {
        clearPick()
        map.overlays.add(Marker(map).apply { position = g; id = "pick" })
        map.invalidate()
        picked = Place("Определяем адрес…", g.latitude, g.longitude)
        scope.launch {
            val name = runCatching { reverse(g) }.getOrNull() ?: "%.5f, %.5f".format(g.latitude, g.longitude)
            picked = Place(name, g.latitude, g.longitude)
        }
    }
    LaunchedEffect(Unit) {
        map.overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?) = false
            override fun longPressHelper(p: GeoPoint?): Boolean { if (p != null) pick(p); return true }
        }))
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { map }, modifier = Modifier.fillMaxSize())

        Column(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp)) {
            TextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true, shape = CircleShape,
                placeholder = { Text("Куда едем?") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                colors = TextFieldDefaults.colors(focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    loading = true
                    scope.launch { results = runCatching { search(query) }.getOrDefault(emptyList()); loading = false }
                })
            )
            if (results.isNotEmpty()) {
                ElevatedCard(Modifier.padding(top = 8.dp).heightIn(max = 320.dp)) {
                    LazyColumn {
                        items(results) { p ->
                            ListItem(headlineContent = { Text(p.name, maxLines = 2) },
                                leadingContent = { Icon(Icons.Default.Place, null) },
                                modifier = Modifier.fillMaxWidth().clickable { go(p) },
                                colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent))
                            HorizontalDivider()
                        }
                    }
                }
            }
        }

        Column(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(12.dp), horizontalAlignment = Alignment.End) {
            FloatingActionButton(onClick = { locOverlay?.myLocation?.let { map.controller.animateTo(it) } ?: enableLocation() }) {
                Icon(Icons.Default.MyLocation, "Моя позиция")
            }
            Spacer(Modifier.height(12.dp))
            if (loading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
            val pk = picked
            if (pk != null) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(pk.name, style = MaterialTheme.typography.titleMedium, maxLines = 3)
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = {
                                startPlace = pk; picked = null; clearPick()
                                map.overlays.add(Marker(map).apply { position = GeoPoint(pk.lat, pk.lon); title = "Старт"; id = "start" })
                                map.invalidate()
                                dest?.let { go(it) }
                            }) { Text("Отсюда") }
                            Button(onClick = { go(pk) }) { Text("Сюда") }
                            TextButton(onClick = { picked = null; clearPick() }) { Text("Закрыть") }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            val d = dest
            if (d != null) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                        startPlace?.let { Text("Старт: ${it.name}", style = MaterialTheme.typography.bodySmall, maxLines = 1) }
                        if (info == null && !loading) Text("Не удалось построить маршрут: $lastError", style = MaterialTheme.typography.bodyMedium)
                        info?.let {
                            Text("%.1f км • %d мин".format(it.meters / 1000, (it.seconds / 60).toInt()),
                                style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        if (navigating && hint.isNotEmpty()) Text(hint, style = MaterialTheme.typography.bodyLarge)
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (info != null) Button(onClick = {
                                if (navigating) { navigating = false; tts.stop() } else navigating = true
                            }) { Icon(if (navigating) Icons.Default.Stop else Icons.Default.Navigation, null) ; Spacer(Modifier.width(8.dp)); Text(if (navigating) "Стоп" else "Поехали") }
                            OutlinedButton(onClick = {
                                navigating = false; dest = null; info = null; startPlace = null; map.overlays.removeAll { it is Polyline || it is Marker }; map.invalidate()
                            }) { Text("Сбросить") }
                        }
                    }
                }
            }
        }
    }
}
